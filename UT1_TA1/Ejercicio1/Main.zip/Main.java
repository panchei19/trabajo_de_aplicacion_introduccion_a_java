/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.td1;

/**
 *
 * @author emili
 */
public class Main {
    public static void main(String[] args) {
        System.out.println("Hello World!");
        
        //System.out.println(TD1.pepe@pepito);
        //System.out.println(nombre completo);
        //System.out.println(TD1.5meses);
        //System.out.println( TD1.int class);
        System.out.println(TD1.$pepe);
        System.out.println(TD1.xyyyzabc123);

    }
}
