/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */
package com.mycompany.td1;

/**
 *
 * @author emili
 */
public class TD1 {

    //public String nombre completo  = "a"; //Es incorrecto ya que no se puede poner un espacio en el nombre del atributo.

    //public int pepe@pepito  = 1; //Es incorrecto debido a que utiliza caracteres especiales en el nombre del atributo.

    //public double 5meses  = 3.0; //Es incorrecto ya que un atributo no puede comenzar con un número.

    //public int class = 20; //Es incorrecto utilizar palanras reservadas como nombres de atributos.
            
    public int $pepe = 1; //Si bien esto parece ser correcto, esta práctica no es recomendada porque no cumple las convenciones.

    public int xyyyzabc123 = 60; //Si bien esto parece ser correcto, no se deberían establecer nombres de atributos largos o difíciles de leer ya que no cumple con las convenciones.
}

public class Main {
    public static void main(String[] args) {
        //System.out.println(TD1.pepe@pepito);
        //System.out.println(nombre completo);
        //System.out.println(TD1.5meses);
        //System.out.println( TD1.int class);
        System.out.println(TD1.$pepe);
        System.out.println(TD1.xyyyzabc123);

    }
}
